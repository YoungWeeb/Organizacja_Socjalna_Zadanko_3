﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Organizacja_Socjalna_Zadanko_3.UserControls
{
    public partial class DonersUC : UserControl
    {
        public DonersUC()
        {
            InitializeComponent();
        }
    }
}
